/*Scala program to print your name*/
object ExPrintName {
       def main(args: Array[String]) {
           println("My name is Mike!")
       }
    }
