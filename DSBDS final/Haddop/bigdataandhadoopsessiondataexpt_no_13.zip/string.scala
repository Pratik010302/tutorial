object ExampleString {
   def main(args: Array[String]) {
        
        //declare and assign string variable "text"
        val text : String = "You are reading SCALA programming language.";
        
        //print the value of string variable "text"
        
        println("Value of text is: " + text);
        
   }
}
